struct s {
    int a;
    float b;
};
struct t {
    int a;
    float b;
};
void f(int m, float n) {
    struct s x;
    struct s y;
    struct t z;
    int p;
    float q;
    x = y;
    x.b = p;
    q = 1.0 + z.a;
    f(z.b, z.a);
}
struct u {
    struct s * a;
    struct t * b;
};

int g(int a) {
    struct u x;
    a = f(1, 0.1);
}
