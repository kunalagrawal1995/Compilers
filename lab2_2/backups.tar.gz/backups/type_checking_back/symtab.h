#include <string>
#include <map>
#include <set>
#include "ast.h"
// NEED TO CHECK ON WHAT TO DO WITH STRUCTS
using namespace std;
class var_type{
public:
	string t;
	var_type * type;
	var_type();
	var_type(string s);
};

class SymTab;

class SymRow{
public:
	string symName; 	// for symbol name
	int var_fun;		// 1 -> func, 0 -> var, 2 -> struct
	int param_local;	// -1 -> global, 0 -> local, i -> ith parameter; >= 1 if it exists  
	var_type * head;
	var_type * tail;
	int size;
	int offset;
	SymTab *symTab;		// location for the symbol table
	SymRow(string inp_symName, int inp_var_fun, int int_param_local, string inp_type, SymTab * symTable);
	SymRow();
	void print_row();
};

class SymTab{
public:
	int insertRow(string name, SymRow * s);
	map <string, SymRow *> sym_rows;
	void print_table();
};

string get_type(var_type * head, string s);

// return type for a binary operator
// (&&,||) -> 0; 
// (==) -> 1; 
// (<,<=,>=,>) -> 2; 
// (+) -> 3; 
// (-) -> 4;  
// (*,/) -> 5; 

var_type* result_type(var_type * left, var_type * right, int op_type); 

var_type* deref(var_type * type);

var_type* ref(var_type * type);

var_type* unary_not(var_type * type);

var_type* unary_minus(var_type * type);

var_type* identifier_type(string id);

var_type* data_member_access(var_type * type, string data_member, int access_type); 		// access_type is 0 for . access, 1 for -> access 

int function_parameter_match(string fn_name, vector<ExpAst *> Exp_List);

var_type* valid_assign(var_type *left, var_type *right);

int casting_binary(ExpAst *left, ExpAst * right);

void casting_assign(var_type * to, ExpAst * from);