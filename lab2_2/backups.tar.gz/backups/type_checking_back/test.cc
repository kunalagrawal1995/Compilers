struct inte{int a;};
int * f(void * a, int * b) {
    float * c;
    return a; 
    return b; 
}

void fn1(int a){
}

float FUNCTION(int a, int *b, int **c, int d[10], int e[10][20]){
	return 1.5;
}

float fn(int a, int *b, int **c, int d[10], int e[10][20]){
	return 2;
}

void fn2(struct inte a, struct inte *b, struct inte *c[10][5]){
}

int main(){
	float f1, f2[10];
	int i, b1[10], b2[20][30], b3[10], b4[5][20], **b5;
	void *v, *v1[10];
	struct inte a, b, **d, *e, *f[5];
	fn1(i);
	fn(f1, &i, b5, b4[5], b4);
	fn(f1, v1[1], b5, b3, b4);
	fn2(a, v, &f);
	&(a.a);
	*(d + i);
	(*(e+i)).a;
	(d+i)[5];
	&b1[5];
	*(d - i);
	&(*(d+i));
	!(i + i);
	-(i + i);
	i = *b1;
	*(d+i) = e;
	b5[1] = &i;	
}

struct intr{int a;};