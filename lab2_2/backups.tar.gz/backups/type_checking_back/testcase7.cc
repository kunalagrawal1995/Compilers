struct s {
    int a;
};
struct t {
    int a;
    int b;
};
int * f(void * a, int * b) {
    float * c;
    c = a;
    b = a; 
}

int g() {
    struct s a, *p;
    struct t * b, **q;
    void * v;
    int i;
    p = &a; 
    q = &b; 
    v = f(*q, &(p->a)); 
    q = v; 
    return (*(*q)).b; 
    i++ = 7;
}
