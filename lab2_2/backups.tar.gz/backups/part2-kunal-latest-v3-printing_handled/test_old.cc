struct myClass{
	float k;
};

float dummy_function(int arr[9]){
	int woah;
	int * a;
	l = 0;
	*a = 10;
	*b = &main;
	a = b = c;
}

void prac() {
	int x, y;
	float j;
	h=0.0;
	k = l->df;
	k = l.m;
	l = *l;
	l = &o;
	y = j(k==0 || y);
	{
		left = right;
		array_pointer = array[i+c];
		j = funcCall(m && n || l, hi, hello);
		s = "HELLO \"GOOD PEOPLE\"";
		k = k-b;
		i = m != !m;
		i = a1<b1 || a2>b2 || a3<=b3 || a4>=b4;
		k = -h(args,args,"THIS COULD BE MODIFIED BY THE VECTOR IMPLEMENTATION");
		k = !l++;
		weird_stuff = -"WEIRD STUFF ALLOWED BY GRAMMAR, ergo peace yo";
		k = (l + m)+n;
		k = l + (m + n);
		*l = l + m;
		**l = l+m;
		*****m->v=&l+m;
		if(!k == 0 && (k==9 || k==8)){
			s = "yolo";
		}
		else{
			s = "oyoy";
		}

		while(a==b){
			s = "yolo";
		}
		for(i = 0; i<n; i++){
			s = "yolo";
		}
		return this * that || this/-4.0e23;

	}


}
