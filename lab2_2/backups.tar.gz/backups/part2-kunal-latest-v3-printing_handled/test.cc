struct inte{int a;};
int * f(void * a, int * b) {
    float * c;
    return b; 
}

void fn1(float a){
}

int FUNCTION(int a, int *b, int **c, int d[10], int e[10][20]){
	return 1.5;
}

float fn(int a, int *b, int **c, int d[10], int e[10][20]){
	return 2;
}

void fn2(struct inte a, struct inte *b, struct inte *c[10][5]){
}

int main(){
	float f1, f2[10];
	int i, b1[10], b2[20][30], b3[10], b4[5][20], **b5;
	void *v, *v1[10];
	struct inte a, b, **d, *e, *f[5];
	i = fn(f1, &i, b5, b4[5], b4);
	i = i + f1;
	b1 < b1;
	i < f1;
	i == i;
	f1 = b5 == b5 + i;
}

struct intr{int a;};