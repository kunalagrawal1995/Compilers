#include <iostream>
#include <string>
using namespace std;

int main(){

string type = "struct mystruct**";
	int i;
	for(i = 0; i<type.length(); ++i){
		if(type[i] == '*'){
			break;
		}
	}
	// i stores index of first appearance of *
	// i stores index of first appearance of *
	cout<<type.substr(7, type.length()) <<endl; 

}