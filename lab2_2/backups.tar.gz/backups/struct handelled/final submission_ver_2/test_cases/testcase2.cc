struct hello {
        int a;
        float b;
};

int main() {
        int b;
        int a;
        struct hello k;  

        // a = k.d; // comments are working now
        a = k.b; // COMMENT

        return 0;
}
