int main()
{
  int a[2.7];
  return 0;
}