int f (int a ) {     
    // int a;
    a=5;
    return a;
}

int main () {
    int a,b;
    a = 5;
    b = f(a);
}
