int returnInt () {
    return 1;
}

int main() {
    int a;
    int b;
    int c[3];

    a = 2;
    b = 4;
	
    // &a = &b; // This is not allowed; pta hai
	
    *(&a) = b; 

    // c[ "Compilers" ] = 4; // This is not allowed; YO

    c[ returnInt() ] = 1;
}