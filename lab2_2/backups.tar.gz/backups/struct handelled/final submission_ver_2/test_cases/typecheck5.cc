int f (int a) {     
    int c;
    c=5;
    return a ;
}

int main () {
    int a,b;
    a = 5;
    b = f();
}