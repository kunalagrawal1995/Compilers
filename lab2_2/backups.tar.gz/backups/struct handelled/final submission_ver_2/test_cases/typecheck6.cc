int main()
{
  int i;
  int j;
  (i+j)++;  // this should not be allowed // you got int
}
