#make clean
#make

i=3
for i in `seq 3 35`;
    do
    	echo checking ./visible_tests/test$i.c
        ./parser < ./visible_tests/test$i.c > junk
        #gcc ./visible_tests/test$i.c
        echo 
        echo
    done    
