struct hello {
        int a;
        float b;
};

int main() {
        int b;
        int a;
        // struct hello k;  

        // a = k;

        return 0;
}
