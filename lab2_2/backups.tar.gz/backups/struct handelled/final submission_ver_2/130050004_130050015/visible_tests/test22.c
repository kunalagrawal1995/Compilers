int * f(void * a, int * b) {
    float * c;
    c=a;
    return b; 
}

