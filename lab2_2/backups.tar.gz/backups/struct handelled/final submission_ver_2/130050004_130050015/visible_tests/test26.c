struct s {
    int a;
};
struct t {
    int a;
    int b;
};

int g() {
    struct s a, *p;
    struct t * b, **q;
    void * v;
    q = v;
}

int main(){
	;
}