int main()
{
  int a;
  a= 5;
  a++=2;
}
