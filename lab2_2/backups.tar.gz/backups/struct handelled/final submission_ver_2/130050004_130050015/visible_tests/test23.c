int * f(void * a, int * b) {
    int * c;
    return c; 
}

