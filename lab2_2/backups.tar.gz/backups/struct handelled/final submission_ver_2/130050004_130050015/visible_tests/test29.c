void f (int a ) {     
    int c;
    c=5;

}

int main(){
	;
}