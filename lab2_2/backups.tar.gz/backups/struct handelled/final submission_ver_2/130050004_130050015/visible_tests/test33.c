int main()
{
  int i;
  int j;
  // (i+j)++;  
  ;
}
