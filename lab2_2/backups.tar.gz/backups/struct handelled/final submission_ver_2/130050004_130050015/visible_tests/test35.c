
float * f(int * a[10], float b[8][5]) {
    return b[0];
}

int main(){
	return 1;
}
