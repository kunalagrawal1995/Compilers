int f (int a ) {     
    int b;
    a=5;
    return a;
}

int main(){
	;
}