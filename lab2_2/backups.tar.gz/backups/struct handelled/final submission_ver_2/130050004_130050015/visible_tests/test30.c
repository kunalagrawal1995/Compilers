void f() {
    ;
}
int main () {
    int a,b;
    a = 5;
    f();
}
