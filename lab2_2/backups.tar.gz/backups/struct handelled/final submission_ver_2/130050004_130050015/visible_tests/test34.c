int main() {
    int a, b;
    &a = &b;
    return 0;
}
