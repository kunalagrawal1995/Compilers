int * f(void * a, int * b) {
    float * c;
    c = a; 
    b = a; 
    return a; 
    return b; 
}

