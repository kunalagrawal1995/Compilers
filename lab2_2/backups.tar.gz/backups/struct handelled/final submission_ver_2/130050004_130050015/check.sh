#!/bin/bash

i=24;
touch ./output/out$i
./parser < ./visible_tests/test$i.c >/dev/null 2> ./output/out$i
echo "GCC OUTPUT\n" >> ./output/out$i
gcc ./visible_tests/test$i.c > /dev/null 2>> ./output/out$i
