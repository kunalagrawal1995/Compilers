/*struct inte{int a;};
struct intr{int a;};
void fn1(){

}

void fn(int a, int *b, int **c, int d[10], int e[10][20]){

}

void fn2(struct inte a, struct inte *b, struct inte *c[10][5]){

}

void fn3(int *a){

}

int main(){
	// float f1, f2[10];
	// int i, b1[10], b2[20][30], b3[10], b4[5][20], **b5;
	// void *v, *v1[10];
	// struct inte a, b, **d, *e, *f[5];
	// fn1();
	// fn(f1, &i, b5, b4[5], b4);
	// fn(f1, v1[1], b5, b3, b4);
	// fn2(a, e, &f);
	struct inte i, *j, k[10];
	int a, *b, **c, p[10], *r[10], t[10][10];
	float d, *e, **f, q[20][30], **z[10][10];
	void * v1, **v2;
	fn3(c);
	// i + a;
	// a == v1;
	// (j + d) == *k;
	// (j - *k) == d;
	// i - a;
	// j * a;
	// i && i;
	// i == i;
	// i > i;
	// j > k;
	// j == k;
	// j && k;

	// a / d;
	// b / a;
	// b / b;
	// b / v1;

	// *(c - a) == b;
	// (t - &p) == a;
	// (z + a) == z; 
	// a + d;
	// b + r;
	// b + t[1];
	// (b - v1) == a;
}
*/


/*struct inte{int a;};
int * f(void * a, int * b) {
    float * c;
    return a; 
    return b; 
}

void fn1(int a){
}

float FUNCTION(int a, int *b, int **c, int d[10], int e[10][20]){
	return 2;
}

float fn(int a, int *b, int **c, int d[10], int e[10][20]){
	return 2;
}

void fn2(struct inte a, struct inte *b, struct inte *c[10][5]){
}

int main(){
	float f1, f2[10];
	int i, b1[10], b2[20][30], b3[10], b4[5][20], **b5;
	void *v, *v1[10];
	struct inte a, b, **d, *e, *f[5];
	fn1(i);
	fn(f1, &i, b5, b4[5], b4);
	fn(f1, v1[1], b5, b3, b4);
	fn2(a, v, &f);
	&(a.a);
	*(d + i);
	(*(e+i)).a;
	(d+i)[5];
	&b1[5];
	*(d - i);
	&(*(d+i));
	!(i + i);
	-(i + i);
	i = *b1;
	*(d+i) = e;
	b5[1] = &i;	
}

struct intr{int a;};*/
/*struct inte{int a;};
struct random *funtion_(){
	struct random *a[10];
}

int main(){

}*/

struct inte{
	float b;
	// int a; 
	// struct random * r;
};

struct f{
	int h;
	float k;
};

int f23(void * a, int * b) {
	int k[ 6 ];
    float * c;
    return k[1]; 
    // return b; 
}

void fn1(float a){
}

int FUNCTION(int a, int *b, int **c, int d[10], int e[10][20]){
	return 1.5;
}

float fn(int a, int *b, int **c, int d[10], int e[10][20]){
	return 2;
}

struct random *fn2(struct inte a, struct inte *b, struct inte *c[10][5]){
}

int main(){
	float f1, f2[10];
	int i, b1[10], b2[20][(3+0x2+04-0b101)], b3[10], b4[5][20], **b5;
	void *v, *v1[(10+011)][(10+011)];
	struct inte a, b, **d, *e, *f[5];
	struct random *r;
	struct f var1, *var2;
	// comparison with void *
	var2 = v;
	var2 == v;
	r->a;
	// checking deref and ref and data member access
	var2 = &var1;
	var1 = *var2;
	f1 = var1.h;
	f1 = var2->k + var2->h;
	//checking the function
	f1 = f23(&i, v);

	//checking strings 
	"hello haha";
	// *b5 = "finally";
	// f2 = 0;
	b5 = 4-3 - (5 == 5);
	i = fn(f1, &i, b5, b4[5], b4);
	!b2;
	// *(&(i = i)) = i;
	i = i + f1;
	b1 < b1;
	i < f1;
	i == i;
	f1 = b5 == b5 + i;
}

struct intr{int a;};